/** 
 * @file course.c
 * @author "Name of author"
 * @date "04/06/2022"
 * @brief "course library for managing courses. Contains course 
 *        type definition and includes course functions"
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/** 
 *  adds a student (enrolls) to the list of students taking a specific course
 * 
 * @param course list of courses respresented by a dynamically allocated array
 * @param student list of students respresented by a dynamically allocated array
 * @return nothing
 */

void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student)); /**< the use of calloc here is for if and only if the amount to total students is 1, thereby efficiently allocating the proper amount of space needed*/
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); /**< the use of realloc here is for is to create enough space for as much student that are need to be stored*/
  }
  course->students[course->total_students - 1] = *student;
}

/** 
 * prints out the course information (i.e. course name, code, total # of students enrolled)
 * and the list of every student enrolled
 * 
 * @param course list of courses respresented by a dynamically allocated array
 * @return nothing
 */

void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/** 
 * computes and returns the student with the highest avgerage (the top student)
 * 
 * @param course list of courses respresented by a dynamically allocated array
 * @return student -> student with the highest average
 */

Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/** 
 * computes and returns the list of students passing a course
 * 
 * @param course list of courses respresented by a dynamically allocated array
 * @param total_passing number of studets passing the current course
 * @return passing -> a list of student type which contains the students passing a current course
 */

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));/**< allocates space for the amount of students passing a current course*/

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i]; /**< fills up the previously empty list with the students pasing the current course*/
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}