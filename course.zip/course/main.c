/** 
 * @mainpage course and student demonstartion
 *
 * Demonstration of student and course functions in mangaing students, including:-
 * - enrolling a student
 * - adding a grade to a student
 * - printing the list of students enrolled in a course
 * - computing the top student with the highest average
 * - generation of a random student
 *
 * @file main.c
 * @author "Name of author"
 * @date "04/06/2022"
 * @brief "Runs demonstration of course and student functions"
 *
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/** 
 * creates a course, enrolls students into it, compututes and 
 * prints the top student and the students passing
 */

int main()
{
  srand((unsigned) time(NULL));

  //create a course "MATH101" and giving it a name and a code
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  //enrolls 20 students in the course
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  //prints out the information of the top student in the MATH101 course
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  //prints out the students who are passing the MATH101 course
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}