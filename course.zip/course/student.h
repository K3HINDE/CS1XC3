/** 
 * @file student.h
 * @author "Name of author"
 * @date "04/06/2022"
 * @brief "student library for managing students. Contains student 
 *        type definition and includes student functions prototypes"
 */


/** 
 * student type declaration for all the needed variables for a student 
 * (i.e. first and last names, id, & grades) 
 */

typedef struct _student 
{ 
  char first_name[50];   /**< the students first name*/
  char last_name[50];    /**< the students last name*/
  char id[11];           /**< the students id*/
  double *grades;        /**< the students grades represented by a dynamically allocated array*/
  int num_grades;        /**< the students number of grades*/
} Student;


void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
