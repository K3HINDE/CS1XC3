/** 
 * @file course.h
 * @author "Name of author"
 * @date "04/06/2022"
 * @brief "course library for managing courses. Contains course 
 *        type definition and includes course functions prototypes"
 */

#include "student.h"
#include <stdbool.h>


/** 
 * course type declaration for all the needed variables pertaining to a course 
 * (i.e. couse name, course codes, students and total # of students enrolled) 
 */

typedef struct _course 
{
  char name[100];         /**< the course name*/
  char code[10];          /**< the course code*/
  Student *students;      /**< the students enrolled*/
  int total_students;     /**< the total num of students enrolled*/
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


